package com.amarin.urlshortenerapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrlShortenerApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
